/* const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

const dynamodb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  const body = JSON.parse(event.body);
  const transactionId = uuidv4();
  const userId = body.userId;
  const amount = body.amount;
  const category = body.category;
  const timestamp = body.timestamp;

  const params = {
    TableName: 'Transactions',
    Item: {
      transactionId: transactionId,
      userId: userId,
      amount: amount,
      category: category,
      timestamp: timestamp,
    },
  };

  try {
    await dynamodb.put(params).promise();
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
      },
      body: JSON.stringify('Transaction added successfully!'),
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
      },
      body: JSON.stringify('Failed to add transaction.'),
    };
  }
}; */

const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

const dynamodb = new AWS.DynamoDB.DocumentClient();
const sns = new AWS.SNS();

exports.handler = async (event) => {
  const body = JSON.parse(event.body);
  const transactionId = uuidv4();
  const userId = body.userId;
  const amount = body.amount;
  const category = body.category;
  const timestamp = body.timestamp;

  const params = {
    TableName: 'Transactions',
    Item: {
      transactionId: transactionId,
      userId: userId,
      amount: amount,
      category: category,
      timestamp: timestamp,
    },
  };

  const snsParams = {
    Message: `A new transaction has been added to your account.\n\nDetails:\nAmount: ${amount}\nCategory: ${category}\nTimestamp: ${timestamp}`,
    Subject: 'New Transaction Added',
    TopicArn: 'arn:aws:sns:us-east-1:984599200839:TransactionNotifications', // Your SNS Topic ARN
  };

  try {
    // Save transaction to DynamoDB
    await dynamodb.put(params).promise();

    // Publish message to SNS topic
    await sns.publish(snsParams).promise();

    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
      },
      body: JSON.stringify(
        'Transaction added and notification sent successfully!'
      ),
    };
  } catch (error) {
    console.error(
      'Error adding transaction or sending SNS notification:',
      error
    );
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
      },
      body: JSON.stringify('Failed to add transaction or send notification.'),
    };
  }
};

const AWS = require('aws-sdk');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

const dynamodb = new AWS.DynamoDB.DocumentClient();

const getSecret = async (secretName) => {
  const client = new AWS.SecretsManager();
  const data = await client.getSecretValue({ SecretId: secretName }).promise();
  try {
    return JSON.parse(data.SecretString);
  } catch (e) {
    return data.SecretString;
  }
};

exports.handler = async (event) => {
  const body = JSON.parse(event.body);
  const email = body.email;
  const password = body.password;

  const secretKey = await getSecret('SecretKey');
  const jwtSecret = await getSecret('JwtSecret');

  const hashedPassword = crypto
    .createHmac('sha256', secretKey)
    .update(password)
    .digest('hex');

  const params = {
    TableName: 'Users',
    Key: {
      email: email,
    },
  };

  try {
    const data = await dynamodb.get(params).promise();
    if (data.Item && data.Item.password === hashedPassword) {
      const token = jwt.sign({ email: email }, jwtSecret, {
        algorithm: 'HS256',
      });
      return {
        statusCode: 200,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Credentials': true,
        },
        body: JSON.stringify({ token: token }),
      };
    } else {
      return {
        statusCode: 400,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Credentials': true,
        },
        body: JSON.stringify('Invalid credentials.'),
      };
    }
  } catch (error) {
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
      },
      body: JSON.stringify('Internal server error.'),
    };
  }
};

/* const AWS = require('aws-sdk');
const crypto = require('crypto');

const dynamodb = new AWS.DynamoDB.DocumentClient();

const getSecret = async (secretName) => {
  const client = new AWS.SecretsManager();
  const data = await client.getSecretValue({ SecretId: secretName }).promise();
  try {
    return JSON.parse(data.SecretString);
  } catch (e) {
    return data.SecretString;
  }
};

exports.handler = async (event) => {
  console.log('Received event:', JSON.stringify(event, null, 2)); // Log the entire event

  try {
    const body = JSON.parse(event.body);
    const nestedBody = JSON.parse(body.body); // Parse the nested body
    console.log('Parsed nested body:', nestedBody); // Log the parsed nested body
    const email = nestedBody.email;
    const password = nestedBody.password;
    console.log('Email:', email); // Log the email
    console.log('Password:', password); // Log the password

    if (!password) {
      throw new Error('Password is required');
    }

    const secretKey = await getSecret('SecretKey');
    console.log('Secret key:', secretKey); // Log the secret key

    const hashedPassword = crypto
      .createHmac('sha256', secretKey)
      .update(password)
      .digest('hex');

    const params = {
      TableName: 'Users',
      Item: {
        email: email,
        password: hashedPassword,
      },
      ConditionExpression: 'attribute_not_exists(email)',
    };

    await dynamodb.put(params).promise();
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
      },
      body: JSON.stringify('User registered successfully!'),
    };
  } catch (error) {
    console.error('Error:', error); // Log the error
    return {
      statusCode: 400,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
      },
      body: JSON.stringify('User already exists or other error occurred.'),
    };
  }
};
*/

const AWS = require('aws-sdk');
const crypto = require('crypto');

const dynamodb = new AWS.DynamoDB.DocumentClient();
const sns = new AWS.SNS();

const getSecret = async (secretName) => {
  const client = new AWS.SecretsManager();
  const data = await client.getSecretValue({ SecretId: secretName }).promise();
  try {
    return JSON.parse(data.SecretString);
  } catch (e) {
    return data.SecretString;
  }
};

exports.handler = async (event) => {
  console.log('Received event:', JSON.stringify(event, null, 2)); // Log the entire event

  try {
    const body = JSON.parse(event.body); // Parse the event body directly
    console.log('Parsed body:', body); // Log the parsed body
    const email = body.email;
    const password = body.password;
    console.log('Email:', email); // Log the email
    console.log('Password:', password); // Log the password

    if (!password) {
      throw new Error('Password is required');
    }

    const secretKey = await getSecret('SecretKey');
    console.log('Secret key:', secretKey); // Log the secret key

    const hashedPassword = crypto
      .createHmac('sha256', secretKey)
      .update(password)
      .digest('hex');

    const params = {
      TableName: 'Users',
      Item: {
        email: email,
        password: hashedPassword,
      },
      ConditionExpression: 'attribute_not_exists(email)',
    };

    await dynamodb.put(params).promise();

    // Subscribe user to SNS topic
    const snsParams = {
      Protocol: 'email',
      TopicArn: 'arn:aws:sns:us-east-1:984599200839:TransactionNotifications', // Your SNS Topic ARN
      Endpoint: email,
    };
    await sns.subscribe(snsParams).promise();

    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
      },
      body: JSON.stringify(
        'User registered and subscribed to notifications successfully!'
      ),
    };
  } catch (error) {
    console.error('Error:', error); // Log the error
    return {
      statusCode: 400,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
      },
      body: JSON.stringify('User already exists or other error occurred.'),
    };
  }
};
